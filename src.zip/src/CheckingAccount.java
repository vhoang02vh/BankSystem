public class CheckingAccount extends Account {
        public CheckingAccount(long accountNumber, double balance) {
            super(accountNumber, balance);
        }

        /**
         * asdfasdffdf.
         * @param d a
         */
        public void withdraw(double d) {

        }

        /**
         * asfasdfasdfd.
         * @param d a
         */
        public void deposit(double d) {

        }
}
