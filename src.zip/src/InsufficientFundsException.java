public class InsufficientFundsException extends BankException {
    /**
     * safdfsdfdasf.
     *
     * @param s s
     */
    public InsufficientFundsException(String s) {
        super(s);
    }

    /**
     * asfasfdfasdf.
     * @param a d
     */
    public void InsufficientFundsException(double a) {

    }
}
