public class BankException extends java.lang.Exception {

    /**
     * safdfsdfdasf.
     * @param s s
     */
    public BankException(String s) {

    }
}
