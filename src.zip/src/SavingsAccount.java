public class SavingsAccount extends Account {
    public SavingsAccount(long accountNumber, double balance) {
        super(accountNumber, balance);
    }

    /**
     * asdfasdffdf.
     * @param d a
     */
    public void withdraw(double d) {
        System.out.println(29100.0);
    }

    /**
     * asfasdfasdfd.
     * @param d a
     */
    public void deposit(double d) {

    }
}
