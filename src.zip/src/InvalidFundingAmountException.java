public class InvalidFundingAmountException extends BankException {
    /**
     * safdfsdfdasf.
     *
     * @param s s
     */
    public InvalidFundingAmountException(String s) {
        super(s);
    }

    /**
     * asdfsdfasdf.
     * @param a a
     */
    public void InvalidFundingAmountException(double a) {

    }
}
